local mod = get_mod("extended_weapon_customization")

-- ##### ┬─┐┌─┐┌─┐ ┬ ┬┬┬─┐┌─┐ #########################################################################################
-- ##### ├┬┘├┤ │─┼┐│ ││├┬┘├┤  #########################################################################################
-- ##### ┴└─└─┘└─┘└└─┘┴┴└─└─┘ #########################################################################################

-- #region vlccp
-- @Backup158: If copying to reseparate VLCCP, uncomment the lines. I just didn't like having duplicates.
local Items = mod:original_require("scripts/utilities/items")
--local VisualLoadoutExtractData = mod:original_require("scripts/extension_systems/visual_loadout/utilities/visual_loadout_extract_data")
--local ItemSlotUtils = mod:original_require("scripts/utilities/item_slot_utils")
-- #endregion vlccp
local VisualLoadoutExtractData = mod:original_require("scripts/extension_systems/visual_loadout/utilities/visual_loadout_extract_data")
local ItemSlotUtils = mod:original_require("scripts/utilities/item_slot_utils")
local master_items = mod:original_require("scripts/backend/master_items")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local unit = Unit
    local pairs = pairs
    local table = table
    local world = World
    local string = string
    local tostring = tostring
    local tonumber = tonumber
    local Managers = Managers
    local unit_node = unit.node
    local table_size = table.size
    local unit_alive = unit.alive
    local table_clear = table.clear
    local string_find = string.find
    local string_match = string.match
    local table_append = table.append
    local table_reverse = table.reverse
    local unit_set_data = unit.set_data
    local unit_get_data = unit.get_data
    local table_combine = table.combine
    local unit_has_node = unit.has_node
    local table_icombine = table.icombine
    local world_destroy_unit = world.destroy_unit
    local table_set_readonly = table.set_readonly
    local unit_get_child_units = unit.get_child_units
    local table_merge_recursive = table.merge_recursive
    local master_items_get_item = master_items.get_item
--#endregion
-- #region Performance VLCCP
-- @Backup158: If copying to reseparate VLCCP, uncomment the lines. I just didn't like having duplicates.
    local log = Log
    local type = type
    -- local unit = Unit
    -- local table = table
    -- local pairs = pairs
    -- local world = World
    local color = Color
    local rawget = rawget
    local ipairs = ipairs
    -- local string = string
    local vector3 = Vector3
    local vector2 = Vector2
    local Log_info = log.info
    -- local tonumber = tonumber
    local lod_group = LODGroup
    local table_set = table.set
    local unit_node = unit.node
    local lod_object = LODObject
    local table_keys = table.keys
    local table_sort = table.sort
    local table_find = table.find
    local table_remove = table.remove
    local matrix4x4_box = Matrix4x4Box
    local string_format = string.format
    local unit_set_data = unit.set_data
    local unit_get_data = unit.get_data
    local unit_has_node = unit.has_node
    local unit_local_pose = unit.local_pose
    local unit_world_pose = unit.world_pose
    local unit_lod_object = unit.lod_object
    local ToolsMasterItems = ToolsMasterItems
    local table_set_readonly = table.set_readonly
    local visibility_contexts = VisibilityContexts
    local world_spawn_unit_ex = world.spawn_unit_ex
    local unit_set_sort_order = unit.set_sort_order
    local unit_has_lod_object = unit.has_lod_object
    local unit_data_table_size = unit.data_table_size
    local unit_animation_event = unit.animation_event
    local unit_set_unit_culling = unit.set_unit_culling
    local unit_set_local_position = unit.set_local_position
    local unit_has_animation_event = unit.has_animation_event
    local lod_group_add_lod_object = lod_group.add_lod_object
    local lod_object_set_static_select = lod_object.set_static_select
    local Unit_set_scalar_for_materials = unit.set_scalar_for_materials
    local Unit_set_texture_for_material = unit.set_texture_for_material
    local Unit_set_vector2_for_materials = unit.set_vector2_for_materials
    local Unit_set_vector3_for_materials = unit.set_vector3_for_materials
    local Unit_set_vector4_for_materials = unit.set_vector4_for_materials
    local Unit_set_texture_for_materials = unit.set_texture_for_materials
    local unit_has_animation_state_machine = unit.has_animation_state_machine
    local unit_set_unit_objects_visibility = unit.set_unit_objects_visibility
    local unit_set_animation_state_machine = unit.set_animation_state_machine
    -- New VLCCP locals from 1.13.0
    local Unit_set_material = Unit.set_material
-- #endregion

-- ##### ┌┬┐┌─┐┌┬┐┌─┐ #################################################################################################
-- #####  ││├─┤ │ ├─┤ #################################################################################################
-- ##### ─┴┘┴ ┴ ┴ ┴ ┴ #################################################################################################

-- #region VLCCP helpers
    local _empty_overrides_table = table.set_readonly({})
    local temp_units = {}
    local SORT_ORDER = {
        FACE_HAIR = 2,
        FACE_SCAR = 1,
        HAIR = 3,
    }
    local _scratchpad = {
        depth = 0,
        sorted_children = {},
    }
    local IGNORE_SLOT_ITEM_ASSIGNING = table.set({
        "slot_primary",
        "slot_secondary",
        "slot_timed",
    })
-- #endregion

local pt = mod:pt()
local PROCESS_SLOTS = {"WEAPON_SKIN", "WEAPON_MELEE", "WEAPON_RANGED"}
local PROCESS_ITEM_TYPES = {"WEAPON_MELEE", "WEAPON_RANGED"}
local TEMP_CHILDREN = {}

-- ##### ┌─┐┬ ┬┌┐┌┌─┐┌┬┐┬┌─┐┌┐┌┌─┐ ####################################################################################
-- ##### ├┤ │ │││││   │ ││ ││││└─┐ ####################################################################################
-- ##### └  └─┘┘└┘└─┘ ┴ ┴└─┘┘└┘└─┘ ####################################################################################

mod.recursive_children = function(self, unit, attachment_units_by_unit, children)
    -- Table
    if not children then
        table_clear(TEMP_CHILDREN)
        children = TEMP_CHILDREN
    end
    -- Get children
    local unit_children = attachment_units_by_unit[unit]
    -- Iterate through children
    for _, unit in pairs(unit_children) do
        -- Add child
        children[#children+1] = unit
        -- Recursive
        self:recursive_children(unit, attachment_units_by_unit, children)
    end
    -- Return
    return children
end

mod.implement_units = function(self, item_unit, attachments, attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup, units)
    if item_unit then
        -- Save unit

        -- Get sub-attachment units
        local units = units or attachment_units_by_unit[item_unit]
        -- Check units
        if units then
            -- Iterate through units
            for _, unit in pairs(units) do
                -- Set attachment slot
                local slot = attachment_id_lookup[unit]
                local attachment_slot = slot and string_match(slot, "[^.]+$")
                unit_set_data(unit, "attachment_slot", attachment_slot)
                unit_set_data(unit, "attachment_slot_long", attachment_id_lookup[unit])
                -- Get item path
                local item_path = mod:fetch_attachment(attachments, attachment_slot)
                -- Set attachment name
                local attachment_name = self.settings.attachment_name_by_item_string[item_path]
                unit_set_data(unit, "attachment_name", attachment_name)
                -- Get attachment master item
                local item = master_items_get_item(item_path)
                -- Check item
                if item and item.attachments then
                    -- Implement units
                    self:implement_units(item_unit, item.attachments, attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup, attachment_units_by_unit[unit])
                end
            end
        end
    end
end

-- mod.register_unit = function(self, unit)
--     pt.spawned_units[unit] = true
--     self:print("registered unit: "..tostring(unit))
-- end

-- mod.delete_all_units = function(self)
--     local world = self:world()
--     if world then
--         for unit, _ in pairs(pt.spawned_units) do
--             if unit and unit_alive(unit) then
--                 world_destroy_unit(world, unit)
--                 mod:print("deleted unit: "..tostring(unit))
--             end
--         end
--         table_clear(pt.spawned_units)
--     else
--         mod:print("error - world: "..tostring(world))
--     end
-- end

-- ##### ┌─┐┬  ┌─┐┌─┐┌─┐  ┌─┐─┐ ┬┌┬┐┌─┐┌┐┌┌─┐┬┌─┐┌┐┌ ##################################################################
-- ##### │  │  ├─┤└─┐└─┐  ├┤ ┌┴┬┘ │ ├┤ │││└─┐││ ││││ ##################################################################
-- ##### └─┘┴─┘┴ ┴└─┘└─┘  └─┘┴ └─ ┴ └─┘┘└┘└─┘┴└─┘┘└┘ ##################################################################

mod:hook_require("scripts/extension_systems/visual_loadout/utilities/visual_loadout_customization", function(VisualLoadoutCustomization)

    -- #region vlccp
        VisualLoadoutCustomization.apply_material_override_item = function (unit, parent_unit, apply_to_parent, material_override_item, in_editor, item_definitions, item_manager, external_overrides)
            local material_override_item_data = VisualLoadoutCustomization._validate_item_name(material_override_item)

            if type(material_override_item_data) == "string" then
                if in_editor then
                    if item_manager and ToolsMasterItems then
                        material_override_item_data = ToolsMasterItems:get(material_override_item)
                    else
                        material_override_item_data = rawget(item_definitions, material_override_item)
                    end
                else
                    material_override_item_data = item_definitions[material_override_item]
                end
            end

            if material_override_item_data then
                if apply_to_parent then
                    VisualLoadoutCustomization._apply_material_override_item(parent_unit, material_override_item_data, in_editor, external_overrides)
                else
                    VisualLoadoutCustomization._apply_material_override_item(unit, material_override_item_data, in_editor, external_overrides)
                end
            end
        end

        VisualLoadoutCustomization.apply_material_overrides = function (item_data, item_unit, parent_unit, attach_settings)
            local apply_to_parent = item_data.material_override_apply_to_parent
            local material_override_items = item_data.material_override_items

            if item_unit and material_override_items then
                for _, material_override_item in pairs(material_override_items) do
                    VisualLoadoutCustomization.apply_material_override_item(item_unit, parent_unit, apply_to_parent, material_override_item, attach_settings.in_editor, attach_settings.item_definitions, attach_settings.item_manager)
                end
            end
        end

        VisualLoadoutCustomization.spawn_item = function (item_data, attach_settings, parent_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment)
            local weapon_skin = VisualLoadoutCustomization._validate_item_name(item_data.slot_weapon_skin)

            if type(weapon_skin) == "string" then
                if attach_settings.in_editor then
                    if attach_settings.item_manager and ToolsMasterItems then
                        weapon_skin = ToolsMasterItems:get(weapon_skin)
                    else
                        weapon_skin = rawget(attach_settings.item_definitions, weapon_skin)
                    end
                else
                    weapon_skin = attach_settings.item_definitions[weapon_skin]
                end
            end

            local item_unit, bind_pose = VisualLoadoutCustomization.spawn_base_unit(item_data, attach_settings, parent_unit, optional_mission_template)
            local skin_overrides = VisualLoadoutCustomization.generate_attachment_overrides_lookup(item_data, weapon_skin)
            local attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup, attachment_units_bind_poses, item_name_by_unit = VisualLoadoutCustomization.spawn_item_attachments(item_data, skin_overrides, attach_settings, item_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment)

            VisualLoadoutCustomization.apply_material_overrides(item_data, item_unit, parent_unit, attach_settings)

            if weapon_skin then
                VisualLoadoutCustomization.apply_material_overrides(weapon_skin, item_unit, parent_unit, attach_settings)
            end

            VisualLoadoutCustomization.add_extensions(item_unit, attachment_units_by_unit and attachment_units_by_unit[item_unit], attach_settings)
            VisualLoadoutCustomization.play_item_on_spawn_anim_event(item_data, parent_unit)

            return item_unit, attachment_units_by_unit, bind_pose, attachment_id_lookup, attachment_name_lookup, attachment_units_bind_poses, item_name_by_unit
        end

        VisualLoadoutCustomization.spawn_base_unit = function (item_data, attach_settings, parent_unit, optional_mission_template, optional_equipment)
            return VisualLoadoutCustomization._spawn_attachment(item_data, attach_settings, parent_unit, optional_mission_template, optional_equipment)
        end

        VisualLoadoutCustomization.spawn_item_attachments = function (item_data, override_lookup, attach_settings, item_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment)
            if not item_unit then
                return nil, nil, nil, nil
            end

            local extract_data = VisualLoadoutExtractData.create(optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names)

            VisualLoadoutExtractData.push(extract_data, item_unit, item_data.name, nil)

            local attachments = item_data.attachments

            if attachments then
                local attachment_names = table.keys(attachments)

                ItemSlotUtils.sort_slot_array_by_priority(attachment_names)

                for ii = 1, #attachment_names do
                    local attachment_name = attachment_names[ii]
                    local attachment_slot_data = attachments[attachment_name]

                VisualLoadoutCustomization._attach_hierarchy(attachment_slot_data, override_lookup, attach_settings, item_unit, attachment_name, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment)
                end
            end

            VisualLoadoutExtractData.pop(extract_data, item_unit)

            return extract_data.attachment_units_by_unit, extract_data.attachment_id_lookup, extract_data.attachment_name_lookup, extract_data.bind_poses_by_unit, extract_data.item_name_by_unit
        end

        VisualLoadoutCustomization.add_extensions = function (item_unit_or_nil, attachment_units_or_nil, attach_settings)
            if attach_settings.spawn_with_extensions then
                local world = attach_settings.world
                local extension_manager = attach_settings.extension_manager

                if item_unit_or_nil then
                    temp_units[1] = item_unit_or_nil

                    extension_manager:add_and_register_units(world, temp_units, 1)
                end

                if attachment_units_or_nil then
                    extension_manager:add_and_register_units(world, attachment_units_or_nil)
                end
            end
        end

        VisualLoadoutCustomization.play_item_on_spawn_anim_event = function (item_data, parent_unit)
            local event_in_parent_state_machine = item_data.event_in_parent_state_machine

            if event_in_parent_state_machine and event_in_parent_state_machine ~= "" and Unit.has_animation_state_machine(parent_unit) and Unit.has_animation_event(parent_unit, event_in_parent_state_machine) then
                Unit.animation_event(parent_unit, event_in_parent_state_machine)
            end
        end

        VisualLoadoutCustomization.attach_hierarchy = function (attachment_slot_data, override_lookup, settings, parent_unit, parent_item_name, attachment_name, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template)
            local extract_data = VisualLoadoutExtractData.create(optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names)

            VisualLoadoutExtractData.push(extract_data, parent_unit, parent_item_name, attachment_name)
            VisualLoadoutCustomization._attach_hierarchy(attachment_slot_data, override_lookup, settings, parent_unit, attachment_name, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template)
            VisualLoadoutExtractData.pop(extract_data, parent_unit)

            return extract_data.attachment_units_by_unit, extract_data.attachment_id_lookup, extract_data.attachment_name_lookup, extract_data.bind_poses_by_unit, extract_data.item_name_by_unit
        end

        VisualLoadoutCustomization.generate_attachment_overrides_lookup = function (item_data, override_item_data)
            if not override_item_data then
                return _empty_overrides_table
            end

            local override_lookup = {}
            local attachments = item_data.attachments
            local override_attachments = override_item_data.attachments

            if not attachments or not override_attachments then
                return _empty_overrides_table
            end

            for attachment_name, attachment_slot_data in pairs(attachments) do
                local override_slot_data = override_attachments[attachment_name]

                VisualLoadoutCustomization._generate_attachment_overrides_recursive(attachment_slot_data, override_slot_data, override_lookup, item_data)
            end

            return override_lookup
        end

        -- ##### Changed from local function ##############################################################################
        -- ##### Added parameters: item
        VisualLoadoutCustomization._generate_attachment_overrides_recursive = function (attachment_slot_data, override_slot_data, override_lookup, item)
            if not override_slot_data then
                return
            end

            local override_item_name = VisualLoadoutCustomization._validate_item_name(override_slot_data.item)

            if override_item_name then
                override_lookup[attachment_slot_data] = override_item_name
            end

            local children = attachment_slot_data.children
            local override_children = override_slot_data.children

            for name, data in pairs(children) do
                local override_data = override_children[name]

                VisualLoadoutCustomization._generate_attachment_overrides_recursive(data, override_data, override_lookup, item)
            end
        end

        -- ##### Changed from local function ##############################################################################
        -- ##### Added parameters: item, item_data, attach_settings
        VisualLoadoutCustomization._find_unit_node_recursive = function (unit, attach_node, item_data, attach_settings, extract_data)
            local attach_node_index

            if tonumber(attach_node) ~= nil then
                attach_node_index = tonumber(attach_node)
                -- mod:print("find_unit_node_recursive: attach_node is a number, using index directly: "..tostring(attach_node_index))
            elseif attach_node and unit and attach_node then
                attach_node_index = unit_has_node(unit, attach_node) and unit_node(unit, attach_node) or 1
                -- mod:print("find_unit_node_recursive: attach_node is a string, found index: "..tostring(attach_node_index).." for node: "..tostring(attach_node))
            else
                attach_node_index = 1
                -- mod:print("flashlight has internal attachment slot: "..tostring(flashlight_attachment_data.flashlight_attachment_slot))
            end

            return unit, attach_node_index
        end

        -- ##### Changed from local function ##############################################################################
        VisualLoadoutCustomization._validate_item_name = function (item)
            if item == "" then
                return nil
            end

            return item
        end

        -- ##### Changed from local function ##############################################################################
        -- ##### Added parameters: extract_data
        VisualLoadoutCustomization._spawn_attachment = function (item_data, attach_settings, parent_unit, optional_mission_template, optional_as_leaf_override_attach_node, optional_as_leaf_map_mode, extract_data)
            if not item_data then
                return nil
            end

            local is_first_person = attach_settings.is_first_person
            local show_in_1p = item_data.show_in_1p
            local only_show_in_1p = item_data.only_show_in_1p

            if is_first_person and not show_in_1p then
                return nil
            end

            if not is_first_person and only_show_in_1p then
                return nil
            end

            local base_unit = Items.base_unit(item_data, attach_settings.breed_name, is_first_person)

            if not base_unit or base_unit == "" then
                return nil
            end

            if attach_settings.is_ui_preview and item_data.hide_in_ui_preview then
                return nil
            end

            local breed_attach_node = not attach_settings.is_minion and item_data.breed_attach_node and item_data.breed_attach_node[attach_settings.breed_name]
            local attach_node = optional_as_leaf_override_attach_node or breed_attach_node or item_data.attach_node
            local attach_node_index

            if parent_unit then
                if tonumber(attach_node) ~= nil then
                    attach_node_index = tonumber(attach_node)
                elseif attach_settings.is_minion then
                    if attach_settings.from_script_component then
                        attach_node_index = unit_has_node(parent_unit, item_data.wielded_attach_node or attach_node) and unit_node(parent_unit, item_data.wielded_attach_node or attach_node) or 1
                    else
                        attach_node_index = unit_has_node(parent_unit, item_data.unwielded_attach_node or attach_node) and unit_node(parent_unit, item_data.unwielded_attach_node or attach_node) or 1
                    end
                elseif attach_node then
                    parent_unit, attach_node_index = VisualLoadoutCustomization._find_unit_node_recursive(parent_unit, attach_node, item_data, attach_settings, extract_data)
                else
                    attach_node_index = 1
                end
            end

            local spawned_unit
            local pose = parent_unit and Unit.world_pose(parent_unit, attach_node_index) or nil

            if attach_settings.from_script_component then
                spawned_unit = World.spawn_unit_ex(attach_settings.world, base_unit, nil, pose)
            elseif string_find(base_unit, "^content/weapons/") and master_items_get_item(base_unit) then
                local spawn_pose = attach_settings.is_minion and attach_settings.attach_pose or pose
                spawned_unit = world_spawn_unit_ex(attach_settings.world, base_unit, nil, spawn_pose)

                if spawned_unit then
                    unit_set_data(spawned_unit, "unit_name", base_unit)
                end
            elseif attach_settings.is_minion then
                spawned_unit = attach_settings.unit_spawner:spawn_unit(base_unit, attach_settings.attach_pose)
            else
                spawned_unit = attach_settings.unit_spawner:spawn_unit(base_unit, pose)
            end

            if not spawned_unit then
                return nil
            end

            local item_type = item_data.item_type

            if item_type then
                local sort_order = SORT_ORDER[item_type]

                if sort_order then
                    Unit.set_sort_order(spawned_unit, sort_order)
                end
            end

            if attach_settings.is_first_person or attach_settings.force_highest_lod_step then
                Unit.set_unit_culling(spawned_unit, false)

                if Unit.has_lod_object(spawned_unit, "lod") then
                    local item_lod_object = Unit.lod_object(spawned_unit, "lod")

                    LODObject.set_static_select(item_lod_object, 0)
                end
            end

            local backpack_offset = item_data.backpack_offset

            if backpack_offset then
                local backpack_offset_node_index = parent_unit and unit_has_node(parent_unit, "j_backpackoffset") and unit_node(parent_unit, "j_backpackoffset") or nil

                if backpack_offset_node_index then
                    local offset_translation = Vector3(0, backpack_offset, 0)

                    Unit.set_local_position(parent_unit, backpack_offset_node_index, offset_translation)
                end
            end

            local bind_pose = Unit.local_pose(spawned_unit, 1)

            if is_first_person and (show_in_1p or only_show_in_1p) then
                Unit.set_unit_objects_visibility(spawned_unit, false, true, VisibilityContexts.RAYTRACING_CONTEXT)
            end

            if parent_unit then
                local map_mode

                if optional_as_leaf_map_mode then
                    map_mode = optional_as_leaf_map_mode
                elseif World[item_data.link_map_mode] then
                    map_mode = World[item_data.link_map_mode]
                elseif attach_settings.skip_link_children and not item_data.force_link_children then
                    map_mode = World.LINK_MODE_NONE
                else
                    map_mode = World.LINK_MODE_NODE_NAME
                end

                World.link_unit(attach_settings.world, spawned_unit, 1, parent_unit, attach_node_index, map_mode)
            end

            if attach_settings.lod_group and Unit.has_lod_object(spawned_unit, "lod") and not attach_settings.is_first_person then
                local attached_lod_object = Unit.lod_object(spawned_unit, "lod")

                LODGroup.add_lod_object(attach_settings.lod_group, attached_lod_object)

                if attach_settings.is_first_person or attach_settings.force_highest_lod_step then
                    LODGroup.set_static_select(attach_settings.lod_group, 0)
                end
            end

            if attach_settings.lod_shadow_group and Unit.has_lod_object(spawned_unit, "lod_shadow") and not attach_settings.is_first_person then
                local attached_lod_object = Unit.lod_object(spawned_unit, "lod_shadow")

                LODGroup.add_lod_object(attach_settings.lod_shadow_group, attached_lod_object)

                if attach_settings.is_first_person or attach_settings.force_highest_lod_step then
                    LODGroup.set_static_select(attach_settings.lod_shadow_group, 0)
                end
            end

            if optional_mission_template then
                local face_state_machine_key = optional_mission_template.face_state_machine_key
                local state_machine = item_data[face_state_machine_key]

                if state_machine and state_machine ~= "" then
                    Unit.set_animation_state_machine(spawned_unit, state_machine)
                end
            end

            return spawned_unit, bind_pose
        end

        -- ##### Changed from local function ##############################################################################
        VisualLoadoutCustomization._real_item = function (attach_settings, item, item_name)
            if not item then
                return nil, nil
            end

            if type(item) == "string" then
                if attach_settings.in_editor then
                    if attach_settings.item_manager and ToolsMasterItems then
                        item = ToolsMasterItems:get(item)
                    else
                        item = rawget(attach_settings.item_definitions, item)
                    end
                else
                    item = attach_settings.item_definitions[item]
                end
            elseif item then
                item_name = item.name
            end

            return item, item_name
        end

        -- ##### Changed from local function ##############################################################################
        VisualLoadoutCustomization._attach_hierarchy = function (attachment_slot_data, override_lookup, attach_settings, parent_unit, attachment_name, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment, optional_forced_attach_node)
            local item_name = attachment_slot_data.item
            local item = VisualLoadoutCustomization._validate_item_name(item_name)
            local override_item = override_lookup[attachment_slot_data]

            item = override_item or item
            item, item_name = VisualLoadoutCustomization._real_item(attach_settings, item, item_name)

            if not item then
                return
            end

            local override_attach_node = optional_forced_attach_node or (attachment_slot_data.leaf_attach_node_override ~= "" and attachment_slot_data.leaf_attach_node_override or nil)
            local override_map_mode = World[attachment_slot_data.link_map_mode_override]
            local attachment_unit, bind_pose = VisualLoadoutCustomization._spawn_attachment(item, attach_settings, parent_unit, optional_mission_template, override_attach_node, override_map_mode, extract_data)

            if optional_equipment and item.slots then
                for _, slot_name in ipairs(item.slots) do
                    if optional_equipment[slot_name] and not IGNORE_SLOT_ITEM_ASSIGNING[slot_name] then
                        optional_equipment[slot_name].item = item
                    end
                end
            end

            if attachment_unit then
                VisualLoadoutExtractData.fill(extract_data, attachment_name, attachment_unit, bind_pose)
                VisualLoadoutExtractData.push(extract_data, attachment_unit, item_name, attachment_name)

                local attachments = item and item.attachments

                VisualLoadoutCustomization._attach_hierarchy_children(attachments, override_lookup, attach_settings, attachment_unit, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template)
                VisualLoadoutExtractData.pop(extract_data, attachment_unit)

                local children = attachment_slot_data.children

                VisualLoadoutCustomization._attach_hierarchy_children(children, override_lookup, attach_settings, attachment_unit, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template)

                local material_override_items = {}
                local item_material_override_items = item.material_override_items

                if item_material_override_items then
                    table.append(material_override_items, item_material_override_items)
                end

                local parent_material_override_items = attachment_slot_data.material_override_items

                if parent_material_override_items then
                    table.append(material_override_items, parent_material_override_items)
                end

                local apply_to_parent = item.material_override_apply_to_parent

                if material_override_items then
                    if not attach_settings.in_editor and item.item_type == "COMPANION_BODY_COAT_PATTERN" then
                        local parent_item_name = parent_unit and extract_data.item_name_by_unit[parent_unit]
                        local parent_item = parent_item_name and attach_settings.item_definitions[parent_item_name]
                        local parent_attachments = parent_item and parent_item.attachments

                        if parent_attachments then
                            for attachment_child_name, _ in pairs(parent_attachments) do
                                local attachment_child_unit = extract_data.attachment_id_lookup[attachment_child_name]

                                if attachment_child_unit then
                                    local attachment_item_name = extract_data.item_name_by_unit[attachment_child_unit]

                                    if attachment_item_name then
                                        Unit.set_data(attachment_child_unit, "attachment_item_name", attachment_item_name)

                                        for _, material_override_item in pairs(material_override_items) do
                                            VisualLoadoutCustomization.apply_material_override_item(attachment_child_unit, parent_unit, apply_to_parent, material_override_item, attach_settings.in_editor, attach_settings.item_definitions, attach_settings.item_manager)
                                        end
                                    end
                                end
                            end
                        end
                    else
                        for _, material_override_item in pairs(material_override_items) do
                            VisualLoadoutCustomization.apply_material_override_item(attachment_unit, parent_unit, apply_to_parent, material_override_item, attach_settings.in_editor, attach_settings.item_definitions, attach_settings.item_manager)
                        end
                    end
                end
            end
        end

        -- ##### Changed from local function ##############################################################################
        VisualLoadoutCustomization._attach_hierarchy_children = function (children, override_lookup, attach_settings, parent_unit, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_forced_attach_node)
            if children then
                _scratchpad.depth = _scratchpad.depth + 1

                local sorted_children = ItemSlotUtils.slot_keys_by_priority(children, _scratchpad.sorted_children[_scratchpad.depth])

                _scratchpad.sorted_children[_scratchpad.depth] = sorted_children

                for ii = 1, #sorted_children do
                    local attachment_name = sorted_children[ii]
                    local child_attachment_slot_data = children[attachment_name]

                    VisualLoadoutCustomization._attach_hierarchy(child_attachment_slot_data, override_lookup, attach_settings, parent_unit, attachment_name, extract_data, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, nil, optional_forced_attach_node)
                end

                _scratchpad.depth = _scratchpad.depth - 1
            end
        end

        -- ##### Changed from local function ##############################################################################
        VisualLoadoutCustomization._apply_material_override = function (unit, material_override_data, in_editor)
            if material_override_data.property_overrides ~= nil then
                for property_name, property_override_data in pairs(material_override_data.property_overrides) do
                    if type(property_override_data) == "number" then
                        Unit_set_scalar_for_materials(unit, property_name, property_override_data, true)
                    else
                        local property_override_data_num = #property_override_data

                        if property_override_data_num == 1 then
                            Unit_set_scalar_for_materials(unit, property_name, property_override_data[1], true)
                        elseif property_override_data_num == 2 then
                            Unit_set_vector2_for_materials(unit, property_name, Vector2(property_override_data[1], property_override_data[2]), true)
                        elseif property_override_data_num == 3 then
                            Unit_set_vector3_for_materials(unit, property_name, Vector3(property_override_data[1], property_override_data[2], property_override_data[3]), true)
                        elseif property_override_data_num == 4 then
                            Unit_set_vector4_for_materials(unit, property_name, Color(property_override_data[1], property_override_data[2], property_override_data[3], property_override_data[4]), true)
                        end
                    end
                end
            end

            if material_override_data.texture_overrides ~= nil then
                for texture_slot, texture_override_data in pairs(material_override_data.texture_overrides) do
                    local resource_by_item = texture_override_data.resource_by_item

                    if resource_by_item == nil then
                        if texture_override_data.material_slot == nil then
                            Unit_set_texture_for_materials(unit, texture_slot, texture_override_data.resource, true)
                        else
                            Unit_set_texture_for_material(unit, texture_override_data.material_slot, texture_slot, texture_override_data.resource)
                        end
                    elseif in_editor then
                        local items_array_size = Unit.data_table_size(unit, "attached_item_names") or 0

                        for ii = 1, items_array_size do
                            local attached_item_name = Unit.get_data(unit, "attached_item_names", ii)
                            local texture_resource = resource_by_item[attached_item_name]

                            if texture_resource then
                                local unit_array_size = Unit.data_table_size(unit, "attached_units_lookup", ii) or 0

                                for jj = 1, unit_array_size do
                                    local attachment_unit = Unit.get_data(unit, "attached_units_lookup", ii, jj)

                                    Unit_set_texture_for_materials(attachment_unit, texture_slot, texture_resource, true)
                                end
                            end
                        end
                    else
                        local attachment_item_name = Unit.get_data(unit, "attachment_item_name")
                        local texture_resource = resource_by_item[attachment_item_name]

                        if texture_resource then
                            Unit_set_texture_for_materials(unit, texture_slot, texture_resource, true)
                        end
                    end
                end
            end
        end

        -- ##### Changed from local table ##############################################################################
        -- Used by the functions
        VisualLoadoutCustomization._default_external_overrides = {
            scalar_material_overrides = {},
            vector2_material_overrides = {},
            vector3_material_overrides = {},
            vector4_material_overrides = {},
            material_overrides = {},
        }

        -- ##### Changed from local table ##############################################################################
        -- Used by the functions
        VisualLoadoutCustomization._empty_overrides_table = table.set_readonly({})

        -- ##### Changed from local table ##############################################################################
        -- Used by the functions
        VisualLoadoutCustomization._empty_external_overrides = table.set_readonly({})

        -- ##### Changed from local function ##############################################################################
        VisualLoadoutCustomization._apply_material_override_item = function (unit, material_override_item, in_editor, external_overrides_or_nil)
            if external_overrides_or_nil == nil then
                external_overrides_or_nil = VisualLoadoutCustomization._empty_external_overrides
            end

            if material_override_item.scalar_material_overrides ~= nil then
                local external_overrides = external_overrides_or_nil.scalar_material_overrides or VisualLoadoutCustomization._default_external_overrides.scalar_material_overrides

                for _, property_override_data in pairs(material_override_item.scalar_material_overrides) do
                    local property_name = property_override_data.property_name
                    local value = external_overrides[property_name] or property_override_data.value

                    Unit_set_scalar_for_materials(unit, property_name, value, true)
                end
            end

            if material_override_item.vector2_material_overrides ~= nil then
                local external_overrides = external_overrides_or_nil.vector2_material_overrides or VisualLoadoutCustomization._default_external_overrides.vector2_material_overrides

                for _, property_override_data in pairs(material_override_item.vector2_material_overrides) do
                    local property_name = property_override_data.property_name
                    local value = external_overrides[property_name] or property_override_data.value

                    Unit_set_vector2_for_materials(unit, property_name, Vector2(value[1], value[2]), true)
                end
            end

            if material_override_item.vector3_material_overrides ~= nil then
                local external_overrides = external_overrides_or_nil.vector3_material_overrides or VisualLoadoutCustomization._default_external_overrides.vector3_material_overrides

                for _, property_override_data in pairs(material_override_item.vector3_material_overrides) do
                    local property_name = property_override_data.property_name
                    local value = external_overrides[property_name] or property_override_data.value

                    Unit_set_vector3_for_materials(unit, property_name, Vector3(value[1], value[2], value[3]), true)
                end
            end

            if material_override_item.vector4_material_overrides ~= nil then
                local external_overrides = external_overrides_or_nil.vector4_material_overrides or VisualLoadoutCustomization._default_external_overrides.vector4_material_overrides

                for _, property_override_data in pairs(material_override_item.vector4_material_overrides) do
                    local property_name = property_override_data.property_name
                    local value = external_overrides[property_name] or property_override_data.value

                    Unit_set_vector4_for_materials(unit, property_name, Color(value[2], value[3], value[4], value[1]), true)
                end
            end

            if material_override_item.texture_material_overrides ~= nil then
                for _, texture_override_data in pairs(material_override_item.texture_material_overrides) do
                    local texture_slot = texture_override_data.texture_slot
                    local material_slot = texture_override_data.material_slot
                    local resource = texture_override_data.texture

                    -- @Backup158: This "if resource" part was previously just this. Leaving this for reference in case this change was bad
                    --[[
                    if material_override_item_data then
                        if apply_to_parent then
                            _apply_material_override_item(parent_unit, material_override_item_data, in_editor)
                        else
                            _apply_material_override_item(unit, material_override_item_data, in_editor)
                        end
                    end
                    ]]
                    if resource ~= nil and resource ~= "" and texture_slot ~= nil and texture_slot ~= "" then
                        if material_slot == nil or material_slot == "" then
                            Unit_set_texture_for_materials(unit, texture_slot, resource, true)
                        else
                            Unit_set_texture_for_material(unit, material_slot, texture_slot, resource)
                        end
                    end
                end
            end

            -- @Backup158: This whole section is new
            if material_override_item.material_overrides ~= nil then
                local external_overrides = external_overrides_or_nil.material_overrides or VisualLoadoutCustomization._default_external_overrides.material_overrides

                for _, material_override_data in pairs(material_override_item.material_overrides) do
                    local material_slot = material_override_data.material_slot
                    local material_resource = external_overrides[material_slot] or material_override_data.material

                    if material_resource ~= nil and material_resource ~= "" and material_slot ~= nil and material_slot ~= "" then
                        Unit_set_material(unit, material_slot, material_resource)
                    end
                end
            end

            if material_override_item.textures_material_overrides_by_items ~= nil then
                for _, texture_override_data in pairs(material_override_item.textures_material_overrides_by_items) do
                    local texture_slot = texture_override_data.texture_slot
                    local material_slot = texture_override_data.material_slot
                    local texture_resource = texture_override_data.texture
                    local item_key = texture_override_data.item

                    if in_editor then
                        local items_array_size = Unit.data_table_size(unit, "attached_item_names") or 0

                        for ii = 1, items_array_size do
                            local attached_item_name = Unit.get_data(unit, "attached_item_names", ii)

                            if attached_item_name == item_key then
                                local unit_array_size = Unit.data_table_size(unit, "attached_units_lookup", ii) or 0

                                for jj = 1, unit_array_size do
                                    local attachment_unit = Unit.get_data(unit, "attached_units_lookup", ii, jj)

                                    if material_slot == nil or material_slot == "" then
                                        Unit_set_texture_for_materials(attachment_unit, texture_slot, texture_resource, true)
                                    else
                                        Unit_set_texture_for_material(attachment_unit, material_slot, texture_slot, texture_resource)
                                    end
                                end
                            end
                        end
                    else
                        local attachment_item_name = Unit.get_data(unit, "attachment_item_name")

                        if attachment_item_name == item_key then
                            if material_slot == nil or material_slot == "" then
                                Unit_set_texture_for_materials(unit, texture_slot, texture_resource, true)
                            else
                                Unit_set_texture_for_material(unit, material_slot, texture_slot, texture_resource)
                            end
                        end
                    end
                end
            end
        end
    -- #endregion vlccp

    VisualLoadoutCustomization.handle_sub_attachments_recursive = function(self, item_data, attachment_name, attachment_unit, attach_settings, attachment_units_by_unit, attachment_id_lookup)

        if item_data.attachments and attachment_units_by_unit[attachment_unit] then

            for _, sub_attachment_unit in pairs(attachment_units_by_unit[attachment_unit]) do

                -- Register unit
                -- mod:register_unit(sub_attachment_unit)

                -- Set attachment slot
                local attachment_slot = attachment_id_lookup[sub_attachment_unit] and string_match(attachment_id_lookup[sub_attachment_unit], "[^.]+$")
                unit_set_data(sub_attachment_unit, "attachment_slot", attachment_slot)
                unit_set_data(attachment_unit, "attachment_slot_long", attachment_id_lookup[sub_attachment_unit])

                -- Get master item
                local item_path = mod:fetch_attachment(item_data.attachments, attachment_slot)

                local attachment_slot_data = mod:fetch_attachment_data(item_data.attachments, attachment_slot)
                local sub_item = master_items_get_item(item_path)
                local parent_attachment_slot_data = mod:fetch_attachment_parent(item_data.attachments, attachment_slot)
                local material_overrides_data = mod:gear_material_overrides(item_data, nil, attachment_slot) or (attachment_slot_data and attachment_slot_data.material_overrides and attachment_slot_data) or (parent_attachment_slot_data and parent_attachment_slot_data.material_overrides and parent_attachment_slot_data) --or sub_item
                if material_overrides_data then
                    VisualLoadoutCustomization.apply_material_overrides(material_overrides_data, sub_attachment_unit, attachment_unit, attach_settings)
                end

                -- Set attachment name
                local sub_attachment_name = mod.settings.attachment_name_by_item_string[item_path] or attachment_name
                unit_set_data(sub_attachment_unit, "attachment_name", sub_attachment_name)

                -- mod:print("sub attachment: "..tostring(sub_attachment_unit).." name: "..tostring(sub_attachment_name).." slot: "..tostring(attachment_slot))

                VisualLoadoutCustomization:handle_sub_attachments_recursive(item_data, attachment_name, sub_attachment_unit, attach_settings, attachment_units_by_unit, attachment_id_lookup)

            end
        end

    end

    mod:hook(VisualLoadoutCustomization, "spawn_item_attachments", function(func, item_data, override_lookup, attach_settings, item_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment, ...)

        -- Check item
        if item_data and mod:cached_table_contains(PROCESS_ITEM_TYPES, item_data.item_type) then
            -- Modify item
            mod:modify_item(item_data)
        end

        -- Fixes
        local fixes = mod:collect_fixes(item_data)
        mod:apply_attachment_fixes(item_data, fixes)
        
        -- Original function
        local attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup, bind_poses_by_unit, item_name_by_unit = func(item_data, override_lookup, attach_settings, item_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment, ...)

        -- local is_ui_item_preview = false
        local is_ui_item_preview = (item_data and (item_data.__is_ui_item_preview or item_data.__is_preview_item or item_data.__attachment_customization))
        if attachment_id_lookup and item_data.attachments then

            mod:implement_units(item_unit, item_data.attachments, attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup)

            -- Collect attachment fixes
            local kitbash_fixes = mod:fetch_attachment_fixes(item_data.structure or item_data.attachments)
            if kitbash_fixes then
                fixes = table_merge_recursive(fixes, kitbash_fixes)
            end

            for _, attachment_unit in pairs(attachment_units_by_unit[item_unit]) do

                -- Set attachment slot
                local attachment_slot = attachment_id_lookup[attachment_unit] and string_match(attachment_id_lookup[attachment_unit], "[^.]+$")
                unit_set_data(attachment_unit, "attachment_slot", attachment_slot)
                unit_set_data(attachment_unit, "attachment_slot_long", attachment_id_lookup[attachment_unit])

                -- Get item path
                local item_path = mod:fetch_attachment(item_data.attachments, attachment_slot)
                local item = master_items_get_item(item_path)
                local parent_attachment_slot_data = mod:fetch_attachment_data(item_data.attachments, attachment_slot)
                local material_overrides_data = mod:gear_material_overrides(item_data, nil, attachment_slot) or (parent_attachment_slot_data and parent_attachment_slot_data.material_overrides and parent_attachment_slot_data) --or item
                mod:generate_material_override_items(material_overrides_data)
                if material_overrides_data and material_overrides_data.material_override_items then
                    VisualLoadoutCustomization.apply_material_overrides(material_overrides_data, attachment_unit, item_unit, attach_settings)
                end

                -- Set attachment name
                local attachment_name = mod.settings.attachment_name_by_item_string[item_path]
                unit_set_data(attachment_unit, "attachment_name", attachment_name)

                if item_data.attachments.slot_trinket_1 and item_data.attachments.slot_trinket_1.item then
                    -- This is a preview item in attachment customization menu

                    is_ui_item_preview = true

                    -- Get item path
                    local item = item_data.attachments.slot_trinket_1.item
                    local item_path = item.name

                    -- Execute ui item init function for attachment
                    local attachment_data = mod.settings.attachment_data_by_item_string[item_path]
                    if attachment_data and attachment_data.ui_item_init then
                        local world = attach_settings.world
                        attachment_data.ui_item_init(world, attachment_unit, attachment_data, true)
                    end

                    -- Collect attachment fixes
                    if item and item.attachments then
                        local kitbash_fixes = mod:fetch_attachment_fixes(item.structure or item.attachments)
                        if kitbash_fixes then
                            fixes = table_merge_recursive(fixes, kitbash_fixes)
                        end

                        VisualLoadoutCustomization:handle_sub_attachments_recursive(item_data, attachment_name, attachment_unit, attach_settings, attachment_units_by_unit, attachment_id_lookup)

                    end

                else -- This is a normal item

                    -- Get master item (already resolved above for this attachment_slot/item_path; avoid a redundant lookup)

                    -- Execute ui item init function for attachment
                    -- Only execute if not from ui profile spawner or ui item preview
                    if is_ui_item_preview and not attach_settings.from_ui_profile_spawner then
                        -- Get attachment data
                        local attachment_data = mod.settings.attachment_data_by_item_string[item_path]
                        if attachment_data and attachment_data.ui_item_init then
                            local world = attach_settings.world
                            attachment_data.ui_item_init(world, attachment_unit, attachment_data)
                        end
                    end

                    if item and item.attachments then

                        -- Collect current attachment names
                        local kitbash_fixes = mod:fetch_attachment_fixes(item.structure or item.attachments)
                        if kitbash_fixes then
                            fixes = table_merge_recursive(fixes, kitbash_fixes)
                        end

                        -- Exlcude from vfx spawner
                        if item.is_kitbash and not item.disable_vfx_spawner_exclusion then

                            for unit, _ in pairs(pt.exclude_from_vfx_spawner) do
                                if not unit or not unit_alive(unit) then
                                    pt.exclude_from_vfx_spawner[unit] = nil
                                end
                            end

                            pt.exclude_from_vfx_spawner[attachment_unit] = true

                            local all_children = mod:recursive_children(attachment_unit, attachment_units_by_unit)
                            for _, child in pairs(all_children) do
                                pt.exclude_from_vfx_spawner[child] = true
                            end

                        elseif item.disable_vfx_spawner_exclusion then

                            -- mod:print("disable_vfx_spawner_exclusion: "..tostring(item.name))

                        end

                        VisualLoadoutCustomization:handle_sub_attachments_recursive(item_data, attachment_name, attachment_unit, attach_settings, attachment_units_by_unit, attachment_id_lookup)

                    end

                end
                
            end

        end

        -- Apply fixes
        mod:apply_unit_fixes(item_data, item_unit, attachment_units_by_unit, attachment_name_lookup, fixes, is_ui_item_preview)

        -- Return
        return attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup, bind_poses_by_unit, item_name_by_unit

    end)

    mod:hook(VisualLoadoutCustomization, "spawn_item", function(func, item_data, attach_settings, parent_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment, ...)

        -- Check item
        if item_data and mod:cached_table_contains(PROCESS_ITEM_TYPES, item_data.item_type) then
            -- Modify item
            mod:modify_item(item_data)
        end

        -- Fixes
        local fixes = mod:collect_fixes(item_data)
        mod:apply_attachment_fixes(item_data, fixes)

        -- Original function
        local item_unit, attachment_units_by_unit, bind_pose, attachment_id_lookup, attachment_name_lookup, attachment_units_bind_poses, item_name_by_unit = func(item_data, attach_settings, parent_unit, optional_map_attachment_name_to_unit, optional_extract_attachment_units_bind_poses, optional_extract_item_names, optional_mission_template, optional_equipment, ...)

        if attachment_id_lookup and item_data.attachments then

            mod:implement_units(item_unit, item_data.attachments, attachment_units_by_unit, attachment_id_lookup, attachment_name_lookup)

            -- Collect current attachment names
            local kitbash_fixes = mod:fetch_attachment_fixes(item_data.structure or item_data.attachments)
            if kitbash_fixes then
                fixes = table_merge_recursive(fixes, kitbash_fixes)
            end

            for _, attachment_unit in pairs(attachment_units_by_unit[item_unit]) do

                -- Set attachment slot
                local attachment_slot = attachment_id_lookup[attachment_unit] and string_match(attachment_id_lookup[attachment_unit], "[^.]+$")
                unit_set_data(attachment_unit, "attachment_slot", attachment_slot)
                unit_set_data(attachment_unit, "attachment_slot_long", attachment_id_lookup[attachment_unit])

                
                -- Get master item
                local item_path = mod:fetch_attachment(item_data.attachments, attachment_slot)
                local item = master_items_get_item(item_path)
                local parent_attachment_slot_data = mod:fetch_attachment_data(item_data.attachments, attachment_slot)
                local material_overrides_data = mod:gear_material_overrides(item_data, nil, attachment_slot) or (parent_attachment_slot_data and parent_attachment_slot_data.material_overrides and parent_attachment_slot_data) --or item
                mod:generate_material_override_items(material_overrides_data)
                if material_overrides_data and material_overrides_data.material_override_items then
                    VisualLoadoutCustomization.apply_material_overrides(material_overrides_data, attachment_unit, item_unit, attach_settings)
                end

                -- Set attachment name
                local attachment_name = mod.settings.attachment_name_by_item_string[item_path]
                unit_set_data(attachment_unit, "attachment_name", attachment_name)

                if item and item.attachments then

                    -- Collect current attachment names
                    local kitbash_fixes = mod:fetch_attachment_fixes(item.structure or item.attachments)
                    if kitbash_fixes then
                        fixes = table_merge_recursive(fixes, kitbash_fixes)
                    end

                    if item.is_kitbash and not item.disable_vfx_spawner_exclusion then

                        local deleted = 0
                        for unit, _ in pairs(pt.exclude_from_vfx_spawner) do
                            if not unit or not unit_alive(unit) then
                                pt.exclude_from_vfx_spawner[unit] = nil
                                deleted = deleted + 1
                            end
                        end
                        if deleted > 0 then
                            -- mod:print("exclude_from_vfx_spawner deleted: "..tostring(deleted))
                        end

                        pt.exclude_from_vfx_spawner[attachment_unit] = true

                        local all_children = mod:recursive_children(attachment_unit, attachment_units_by_unit)
                        for _, child in pairs(all_children) do
                            pt.exclude_from_vfx_spawner[child] = true
                        end

                    elseif item.disable_vfx_spawner_exclusion then

                        -- mod:print("disable_vfx_spawner_exclusion: "..tostring(item.name))

                    end

                    VisualLoadoutCustomization:handle_sub_attachments_recursive(item_data, attachment_name, attachment_unit, attach_settings, attachment_units_by_unit, attachment_id_lookup)

                end

            end

        end

        -- Apply fixes
        mod:apply_unit_fixes(item_data, item_unit, attachment_units_by_unit, attachment_name_lookup, fixes, true)

        -- Return
        return item_unit, attachment_units_by_unit, bind_pose, attachment_id_lookup, attachment_name_lookup, attachment_units_bind_poses, item_name_by_unit

    end)

    mod:hook(VisualLoadoutCustomization, "generate_attachment_overrides_lookup", function(func, item_data, override_item_data, ...)

        -- Original function
        local override_lookup = func(item_data, override_item_data, ...)
        
        if mod:cached_table_contains(PROCESS_ITEM_TYPES, item_data.item_type) then
            if override_lookup and table_size(override_lookup) > 0 then
                for attachment_slot, replacement_path in pairs(override_lookup) do
                    if not string_find(replacement_path, "skins") then
                        override_lookup[attachment_slot] = nil
                    end
                end
            end
        end

        -- Return
        return override_lookup
    end)

end)
